﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;


namespace WebApplication1.Controllers
{
    public class DemoController : Controller
    {
        [Authorize(Roles = "Administrator")]
        public IActionResult OnlyAdministratorAccess()
        {
            ViewData["userRole"] = "Administrator";
            return View("demo");
        }
        [Authorize(Roles = "GroupUser,User")]
        public IActionResult MultipleRoleAccess()
        {
            ViewData["userRole"] = "GroupUser,User";
            return View("demo");
        }

        [Authorize(Roles = "GroupUser")]
        [Authorize(Roles = "User")]
        public IActionResult MultipleRoleAccess1()
        {
            ViewData["userRole"] = "GroupUser,User";
            return View("demo");
        }

    }
}
