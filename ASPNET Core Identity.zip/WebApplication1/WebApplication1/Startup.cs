﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace WebApplication1
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(
                    Configuration.GetConnectionString("DefaultConnection")));
            //services.AddDefaultIdentity<IdentityUser>()
            //    .AddEntityFrameworkStores<ApplicationDbContext>();

            services.AddIdentity<IdentityUser, IdentityRole>()
              .AddEntityFrameworkStores<ApplicationDbContext>();

            //Overide the configuration  
            services.Configure<IdentityOptions>(opt =>
            {
                // Password settings  
                opt.Password.RequireDigit = true;
                opt.Password.RequiredLength = 10;

                // Lockout settings  
                opt.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(60);
                opt.Lockout.MaxFailedAccessAttempts = 5;

                //Signin option
                //opt.SignIn.RequireConfirmedEmail = false;

                // User settings  
                //opt.User.RequireUniqueEmail = true;

                //Token Option
                opt.Tokens.AuthenticatorTokenProvider = "Name of AuthenticatorTokenProvider";

            });

            // Cookie settings  
            services.ConfigureApplicationCookie(options =>
            {
                options.Cookie.Expiration = TimeSpan.FromDays(150);
                options.Cookie.HttpOnly = true;
                options.LoginPath = "/Account/Login";
                options.LogoutPath = "/Account/Logout";
                options.SlidingExpiration = true;
            });


            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IServiceProvider serviceProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
            CreateUsersAndRoles(serviceProvider).Wait();
        }

        private async Task CreateUsersAndRoles(IServiceProvider serviceProvider)
        {
            //initializing custom roles   
            var RoleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var UserManager = serviceProvider.GetRequiredService<UserManager<IdentityUser>>();
            string[] roleNames = { "Administrator", "GroupUser", "User", "Guest" };
            IdentityResult roleResult;

            foreach (var roleName in roleNames)
            {
                var roleExist = await RoleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    //create the roles and seed them to the database: Question 1  
                    roleResult = await RoleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            IdentityUser user = await UserManager.FindByEmailAsync("jignesht@gmail.com");

            if (user == null)
            {
                user = new IdentityUser()
                {
                    UserName = "jignesht@gmail.com",
                    Email = "jignesht@gmail.com",
                };
                await UserManager.CreateAsync(user, "abC@123abca");
            }
            await UserManager.AddToRoleAsync(user, "Administrator");


            IdentityUser user1 = await UserManager.FindByEmailAsync("tejast@gmail.com");

            if (user1 == null)
            {
                user1 = new IdentityUser()
                {
                    UserName = "tejast@gmail.com",
                    Email = "tejast@gmail.com",
                };
                await UserManager.CreateAsync(user1, "xyZ@123abca");
            }
            await UserManager.AddToRoleAsync(user1, "GroupUser");

            IdentityUser user2 = await UserManager.FindByEmailAsync("rakesht@gmail.com");

            if (user2 == null)
            {
                user2 = new IdentityUser()
                {
                    UserName = "rakesht@gmail.com",
                    Email = "rakesht@gmail.com",
                };
                await UserManager.CreateAsync(user2, "pQr@123abca");
            }
            await UserManager.AddToRoleAsync(user2, "User");


            IdentityUser user3 = await UserManager.FindByEmailAsync("guest@gmail.com");

            if (user3 == null)
            {
                user3 = new IdentityUser()
                {
                    UserName = "guest@gmail.com",
                    Email = "guest@gmail.com",
                };
                await UserManager.CreateAsync(user3, "pQrz@123abca");
            }
            await UserManager.AddToRoleAsync(user3, "Guest");
        }

    }
}
